﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ATMApp.Models
{
    public class CardModel
    {
        public string CardNumber { get; set; }
        public string UserName { get; set; }
        public double Balance { get; set; }
    }
}
